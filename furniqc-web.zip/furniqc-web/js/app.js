// ============================================================
// FurniQc — app UI
// Renders the 5 screens (Home, Inspection, Photos, Reports,
// Settings) and wires them to state.js / googleDrive.js /
// googleSheets.js / pdfImport.js / pdfExport.js.
// ============================================================

let currentInspectionId = null; // the inspection currently open in the New QC Inspection screen

function $(sel, root = document) { return root.querySelector(sel); }
function $all(sel, root = document) { return Array.from(root.querySelectorAll(sel)); }

function showScreen(name) {
  $all(".screen").forEach((s) => s.classList.remove("active"));
  $(`#screen-${name}`).classList.add("active");
  $all(".nav-item").forEach((n) => n.classList.toggle("active", n.dataset.screen === name));
  if (name === "home") renderHome();
  if (name === "reports") renderReports();
}

// ---------------------------------------------------------------
// HOME
// ---------------------------------------------------------------
function renderHome() {
  const all = Object.values(APP_STATE.inspections);
  const completed = all.filter((i) => i.status === "approved").length;
  const rejected = all.filter((i) => i.status === "rejected").length;
  const stats = getDashboardStats();
  const totalApproved = Object.values(stats).reduce((s, d) => s + d.approved, 0);
  const totalRejected = Object.values(stats).reduce((s, d) => s + d.rejected, 0);
  const totalAll = totalApproved + totalRejected;
  const pct = totalAll ? Math.round((totalApproved / totalAll) * 100) : 0;

  $("#home-completed").textContent = completed;
  $("#home-rejected").textContent = rejected;
  $("#home-pct").textContent = `${pct}% approved`;

  $("#home-dept-breakdown").innerHTML = CONFIG.DEPARTMENTS.map(
    (d) => `<span>${d} · ${stats[d].pctApproved}%</span>`
  ).join("");
}

// ---------------------------------------------------------------
// NEW QC INSPECTION
// ---------------------------------------------------------------
function startInspection(artNo, qcType) {
  const inspection = makeInspection({ artNo, qcType, inspector: $("#settings-inspector-name").value || "Unassigned" });
  currentInspectionId = inspection.id;
  const project = APP_STATE.artProjects[artNo];
  Object.values(project.drItems).forEach((item) => addLineItemToInspection(inspection.id, item));
  renderInspectionScreen();
  showScreen("inspection");
}

async function handlePdfImport(file) {
  const parsed = await PdfImport.parseJobCardPdf(file);
  if (!parsed.artNo) {
    alert("Couldn't find an Art No in this PDF — check the file or enter details manually.");
    return;
  }
  const project = upsertArtProject({
    artNo: parsed.artNo,
    projectName: parsed.projectName,
    client: "",
    poNo: parsed.poNo
  });
  parsed.lineItems.forEach((item) => upsertDrItem(project.artNo, item));
  startInspection(project.artNo, $("#new-qc-type").value);
}

function renderInspectionScreen() {
  const insp = APP_STATE.inspections[currentInspectionId];
  const project = APP_STATE.artProjects[insp.artNo];

  $("#inspection-title").textContent = `${project.artNo} · QC inspection`;
  $("#inspection-subtitle").textContent = project.projectName;

  const items = Object.values(insp.lineItems);
  $("#inspection-line-items").innerHTML = items
    .map((item) => renderLineItemCard(insp, item))
    .join("");

  bindLineItemEvents();
}

function renderLineItemCard(insp, item) {
  const paramsHtml = Object.entries(item.parameters)
    .map(([name, result]) => renderParamRow(item.drNo, name, result))
    .join("");

  const rejectedParam = Object.entries(item.parameters).find(([, r]) => r.state === "Rejected");
  const rejectionHtml = rejectedParam
    ? `<div class="rejection-box">
         <p style="font-weight:500;">${rejectedParam[0]} — rejected</p>
         <p>Reason: ${rejectedParam[1].reason || "-"} · Severity: ${rejectedParam[1].severity || "-"}</p>
       </div>`
    : "";

  const photosHtml = item.photos
    .map(
      (p) => `<div class="photo-tile">
                <img src="${p.localUrl}" />
                <button class="photo-delete" data-drno="${item.drNo}" data-photo="${p.id}">✕</button>
                <button class="photo-recapture" data-drno="${item.drNo}" data-photo="${p.id}">↻</button>
              </div>`
    )
    .join("");

  return `
    <div class="card" data-drno="${item.drNo}">
      <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:8px;">
        <div>
          <p style="margin:0; font-size:13px; font-weight:500;">
            <span class="badge badge-drno">${item.drNo}</span>
            <span class="badge badge-qty">Qty: ${item.qty}</span>
          </p>
          <p style="margin:4px 0 0; font-size:12px;">${item.productName}</p>
          <p style="margin:2px 0 0; font-size:11px; color:var(--text-muted);">${item.size} · ${item.department}</p>
        </div>
        <button class="back-btn exclude-item-btn" data-drno="${item.drNo}" title="Remove from this inspection (not ready yet)">🗑</button>
      </div>

      <div style="display:flex; flex-direction:column; gap:6px; margin-bottom:8px;">${paramsHtml}</div>
      ${rejectionHtml}

      <textarea class="remarks-input" data-drno="${item.drNo}" placeholder="Remarks">${item.remarks}</textarea>

      <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
        ${photosHtml}
        <label class="photo-add">
          📷
          <input type="file" accept="image/*" capture="environment" class="photo-input" data-drno="${item.drNo}" style="display:none;" />
        </label>
      </div>
    </div>`;
}

function renderParamRow(drNo, paramName, result) {
  const pill = (state, label) =>
    `<span class="state-pill state-${state.toLowerCase().replace("/", "")} ${result.state === state ? "active" : ""}"
           data-drno="${drNo}" data-param="${paramName}" data-state="${state}">${label}</span>`;
  return `
    <div style="display:flex; justify-content:space-between; align-items:center;">
      <span style="font-size:12px; color:var(--text-secondary);">${paramName}</span>
      <span class="state-toggle">
        ${pill("OK", "OK")}
        ${pill("Rejected", "Rejected")}
        ${pill("N/A", "N/A")}
      </span>
    </div>`;
}

function bindLineItemEvents() {
  // 3-way OK / Rejected / N-A toggle
  $all(".state-pill").forEach((el) =>
    el.addEventListener("click", () => {
      const { drno, param, state } = el.dataset;
      if (state === "Rejected") {
        const reason = prompt(`Rejection reason for ${param}?\n(${CONFIG.REJECTION_REASONS.join(", ")})`);
        const severity = prompt(`Severity? (${CONFIG.SEVERITY_LEVELS.join(", ")})`);
        setParameterResult(currentInspectionId, drno, param, { state, reason, severity });
      } else {
        setParameterResult(currentInspectionId, drno, param, { state });
      }
      renderInspectionScreen();
    })
  );

  // Remove a Dr No from this inspection round entirely (§4a partial QC)
  $all(".exclude-item-btn").forEach((el) =>
    el.addEventListener("click", () => {
      if (confirm(`Remove ${el.dataset.drno} from this inspection? (not ready yet — can QC it later)`)) {
        excludeLineItem(currentInspectionId, el.dataset.drno);
        renderInspectionScreen();
      }
    })
  );

  // Remarks
  $all(".remarks-input").forEach((el) =>
    el.addEventListener("change", () => {
      APP_STATE.inspections[currentInspectionId].lineItems[el.dataset.drno].remarks = el.value;
      saveState();
    })
  );

  // Photo capture -> immediate Drive upload (confirmed §9 Q4)
  $all(".photo-input").forEach((el) =>
    el.addEventListener("change", async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      await capturePhoto(el.dataset.drno, file);
    })
  );

  // Per-photo delete
  $all(".photo-delete").forEach((el) =>
    el.addEventListener("click", async () => {
      const { drno, photo } = el.dataset;
      const item = APP_STATE.inspections[currentInspectionId].lineItems[drno];
      const photoRecord = item.photos.find((p) => p.id === photo);
      if (photoRecord?.driveFileId) await GoogleDrive.deletePhoto(photoRecord.driveFileId);
      deletePhotoFromLineItem(currentInspectionId, drno, photo);
      renderInspectionScreen();
    })
  );

  // Per-photo recapture (retake, replace in place — not delete+re-add)
  $all(".photo-recapture").forEach((el) =>
    el.addEventListener("click", () => {
      const input = document.createElement("input");
      input.type = "file";
      input.accept = "image/*";
      input.capture = "environment";
      input.onchange = async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        await recaptureExisting(el.dataset.drno, el.dataset.photo, file);
      };
      input.click();
    })
  );
}

async function capturePhoto(drNo, file) {
  const insp = APP_STATE.inspections[currentInspectionId];
  const project = APP_STATE.artProjects[insp.artNo];
  const photoId = `p_${Date.now()}`;
  const localUrl = URL.createObjectURL(file);

  // Show it immediately (optimistic UI), then upload to Drive in the background.
  addPhotoToLineItem(currentInspectionId, drNo, { id: photoId, localUrl, driveFileId: null });
  renderInspectionScreen();

  if (GoogleAuth.isSignedIn()) {
    try {
      const idx = insp.lineItems[drNo].photos.length;
      const result = await GoogleDrive.uploadPhoto({
        artNo: project.artNo,
        drNo,
        qcDate: insp.qcDate,
        qcType: insp.qcType,
        fileBlob: file,
        fileName: `photo_${String(idx).padStart(3, "0")}.jpg`
      });
      recapturePhoto(currentInspectionId, drNo, photoId, { driveFileId: result.id });
    } catch (e) {
      console.error("Drive upload failed, photo stays local until reconnected:", e);
    }
  }
}

async function recaptureExisting(drNo, photoId, file) {
  const item = APP_STATE.inspections[currentInspectionId].lineItems[drNo];
  const existing = item.photos.find((p) => p.id === photoId);
  const localUrl = URL.createObjectURL(file);
  recapturePhoto(currentInspectionId, drNo, photoId, { localUrl });
  renderInspectionScreen();

  if (existing?.driveFileId) {
    await GoogleDrive.overwritePhoto({ driveFileId: existing.driveFileId, fileBlob: file });
  } else if (GoogleAuth.isSignedIn()) {
    const insp = APP_STATE.inspections[currentInspectionId];
    const project = APP_STATE.artProjects[insp.artNo];
    const result = await GoogleDrive.uploadPhoto({
      artNo: project.artNo, drNo, qcDate: insp.qcDate, qcType: insp.qcType,
      fileBlob: file, fileName: `photo_${photoId}.jpg`
    });
    recapturePhoto(currentInspectionId, drNo, photoId, { driveFileId: result.id });
  }
}

async function saveCurrentInspection() {
  const insp = finalizeInspection(currentInspectionId);
  const project = APP_STATE.artProjects[insp.artNo];
  if (GoogleAuth.isSignedIn()) {
    await GoogleSheets.appendInspection(insp, project);
  } else {
    alert("Saved locally — sign in to Google (Settings) to push this to the QC Report Sheet.");
  }
  showScreen("home");
}

function saveCurrentInspectionAsPdf() {
  const insp = APP_STATE.inspections[currentInspectionId];
  const project = APP_STATE.artProjects[insp.artNo];
  PdfExport.exportArtWisePdf(project, insp); // primary export: Art-No-wise, all Dr No in one PDF
}

// ---------------------------------------------------------------
// REPORTS — QC log grouped Art No wise + Dashboard
// ---------------------------------------------------------------
function renderReports() {
  const stats = getDashboardStats();
  $("#dashboard-cards").innerHTML = CONFIG.DEPARTMENTS.map((dept) => {
    const s = stats[dept];
    return `
      <div class="card">
        <div style="display:flex; justify-content:space-between; font-size:12px; margin-bottom:6px;">
          <span style="font-weight:500;">${dept}</span><span style="color:var(--ok-text);">${s.pctApproved}% approved</span>
        </div>
        <div style="height:6px; border-radius:3px; background:var(--rejected-bg);">
          <div style="height:100%; width:${s.pctApproved}%; border-radius:3px; background:var(--ok-text);"></div>
        </div>
        <p style="font-size:11px; color:var(--text-muted); margin:4px 0 0;">${s.approved} approved · ${s.rejected} rejected</p>
      </div>`;
  }).join("");

  // Group inspections by Art No (confirmed grouping)
  const byArt = {};
  Object.values(APP_STATE.inspections).forEach((insp) => {
    if (!byArt[insp.artNo]) byArt[insp.artNo] = [];
    byArt[insp.artNo].push(insp);
  });

  $("#qc-log-groups").innerHTML = Object.entries(byArt)
    .map(([artNo, inspections]) => renderArtGroup(artNo, inspections))
    .join("");

  bindReportEvents();
}

function renderArtGroup(artNo, inspections) {
  const project = APP_STATE.artProjects[artNo];
  const rejectedCount = inspections.filter((i) => i.status === "rejected").length;
  const itemsHtml = inspections
    .flatMap((insp) =>
      Object.values(insp.lineItems).map((item) => {
        const rejected = Object.values(item.parameters).some((p) => p.state === "Rejected");
        return `
          <div style="padding:6px 0; border-top:1px solid var(--border);">
            <div style="display:flex; justify-content:space-between; align-items:center;">
              <div>
                <p style="font-size:12px; font-weight:500; margin:0;">${item.drNo} · ${item.productName}</p>
                <p style="font-size:11px; color:var(--text-muted); margin:1px 0 0;">${insp.qcType} · ${insp.qcDate}</p>
              </div>
              <span class="badge" style="background:${rejected ? "var(--rejected-bg)" : "var(--ok-bg)"}; color:${rejected ? "var(--rejected-text)" : "var(--ok-text)"};">
                ${rejected ? "Rejected" : "Approved"}
              </span>
            </div>
            <div class="btn-row" style="margin-top:6px;">
              <button class="btn btn-secondary view-record-btn" data-insp="${insp.id}" data-drno="${item.drNo}">👁 View</button>
              <button class="btn btn-secondary change-record-btn" data-insp="${insp.id}" data-drno="${item.drNo}">✏️ Change</button>
              <button class="btn btn-secondary pdf-record-btn" data-insp="${insp.id}" data-drno="${item.drNo}">⬇ PDF</button>
            </div>
          </div>`;
      })
    )
    .join("");

  return `
    <div class="card" style="padding:0; overflow:hidden;">
      <div style="background:var(--surface-muted); padding:10px 12px; display:flex; justify-content:space-between; align-items:center;">
        <div>
          <p style="font-size:13px; font-weight:500; margin:0;">${artNo}</p>
          <p style="font-size:11px; color:var(--text-secondary); margin:1px 0 0;">${project.projectName}</p>
        </div>
        <span style="font-size:11px; color:${rejectedCount ? "var(--rejected-text)" : "var(--ok-text)"}; font-weight:500;">
          ${rejectedCount ? rejectedCount + " rejected" : "All approved"}
        </span>
      </div>
      <div style="padding:8px 12px;">${itemsHtml}</div>
      <div style="padding:8px 12px; border-top:1px solid var(--border);">
        <button class="btn btn-secondary" style="width:100%;" onclick="downloadArtGroupPdf('${artNo}')">⬇ Download full ${artNo} QC report</button>
      </div>
    </div>`;
}

function downloadArtGroupPdf(artNo) {
  const project = APP_STATE.artProjects[artNo];
  const inspections = Object.values(APP_STATE.inspections).filter((i) => i.artNo === artNo);
  // Combine every inspection's line items into one synthetic inspection object for a single PDF.
  const merged = { ...inspections[0], lineItems: {} };
  inspections.forEach((insp) => Object.assign(merged.lineItems, insp.lineItems));
  PdfExport.exportArtWisePdf(project, merged);
}

function bindReportEvents() {
  $all(".pdf-record-btn").forEach((el) =>
    el.addEventListener("click", () => {
      const insp = APP_STATE.inspections[el.dataset.insp];
      const project = APP_STATE.artProjects[insp.artNo];
      PdfExport.exportSingleDrNoPdf(project, insp, el.dataset.drno);
    })
  );
  $all(".view-record-btn, .change-record-btn").forEach((el) =>
    el.addEventListener("click", () => {
      currentInspectionId = el.dataset.insp;
      renderInspectionScreen();
      showScreen("inspection");
    })
  );
}

// ---------------------------------------------------------------
// INIT
// ---------------------------------------------------------------
window.addEventListener("DOMContentLoaded", () => {
  $all(".nav-item").forEach((el) => el.addEventListener("click", () => showScreen(el.dataset.screen)));
  $("#back-to-home").addEventListener("click", () => showScreen("home"));

  $("#pdf-upload-input").addEventListener("change", (e) => {
    if (e.target.files[0]) handlePdfImport(e.target.files[0]);
  });
  $("#manual-create-btn").addEventListener("click", () => {
    const artNo = $("#manual-art-no").value.trim();
    const projectName = $("#manual-project-name").value.trim();
    if (!artNo || !projectName) return alert("Art No and Project Name are required.");
    upsertArtProject({ artNo, projectName, client: "", poNo: "" });
    startInspection(artNo, $("#new-qc-type").value);
  });

  $("#save-qc-btn").addEventListener("click", saveCurrentInspection);
  $("#save-pdf-btn").addEventListener("click", saveCurrentInspectionAsPdf);

  $("#google-signin-btn").addEventListener("click", () => GoogleAuth.signIn());
  GoogleAuth.init(() => {
    $("#google-signin-btn").textContent = "Signed in ✓";
  });

  showScreen("home");
});
