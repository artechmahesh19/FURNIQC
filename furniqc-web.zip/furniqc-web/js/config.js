// ============================================================
// FurniQc — configuration
// Fill in the values below with your own Google Cloud project
// credentials before running the app. See README.md for the
// step-by-step setup (enabling Drive API + Sheets API, creating
// an OAuth Client ID, and creating the destination Google Sheet).
// ============================================================

const CONFIG = {
  // OAuth 2.0 Client ID from Google Cloud Console (APIs & Services > Credentials)
  GOOGLE_CLIENT_ID: "YOUR_OAUTH_CLIENT_ID.apps.googleusercontent.com",

  // API key from Google Cloud Console (used for Sheets/Drive discovery docs)
  GOOGLE_API_KEY: "YOUR_GOOGLE_API_KEY",

  // Scopes requested at sign-in: Drive file access (only files this app
  // creates/opens) + full Sheets access to append rows and update the dashboard
  GOOGLE_SCOPES: [
    "https://www.googleapis.com/auth/drive.file",
    "https://www.googleapis.com/auth/spreadsheets"
  ].join(" "),

  // The Google Sheet that receives QC Report rows (see js/googleSheets.js).
  // Create a blank Sheet, copy its ID out of the URL, and paste it here.
  // https://docs.google.com/spreadsheets/d/<THIS_PART>/edit
  QC_REPORT_SPREADSHEET_ID: "YOUR_SPREADSHEET_ID",

  // Name of the tab that receives one row per inspected Dr No.
  // Column order matches QC_REPORT_.xlsx exactly — see js/googleSheets.js
  QC_LOG_SHEET_NAME: "Sheet1",

  // Name of the tab that shows department-wise Approved/Rejected % (auto-written)
  DASHBOARD_SHEET_NAME: "Dashboard",

  // Root folder name created in the signed-in user's Drive for all photo backups.
  // Structure: FurniQc / {Art No} / {Dr No} / {QC Date}_{QC Type} / photo_001.jpg
  DRIVE_ROOT_FOLDER_NAME: "FurniQc",

  // The 8 QC checklist parameters, in the exact order used by QC_REPORT_.xlsx
  QC_PARAMETERS: [
    "Outer/Polish/Veneer/Pu/Metal",
    "Edgeband",
    "GVT/Leg",
    "Glass/Lock",
    "Design As Per Drawing",
    "Handle/Knob/Profile",
    "Fabric",
    "Metal"
  ],

  // Standard rejection reasons shown in the dropdown (§10-A-1 of the spec).
  // "Other" always falls back to the free-text field.
  REJECTION_REASONS: [
    "Polish Mismatch",
    "Size Mismatch",
    "Hardware Missing",
    "Edgeband Peeling",
    "Laminate Defect",
    "Stitching Defect",
    "Fabric Mismatch",
    "Other"
  ],

  SEVERITY_LEVELS: ["Minor", "Major", "Critical"],

  DEPARTMENTS: ["Panel", "Sofa", "Bed", "Office Table"],

  // Keyword → department map used for auto-detecting Department from the
  // imported PDF's Product Name / Dr No text (§9, Open Q2)
  DEPARTMENT_KEYWORDS: {
    Sofa: ["sofa", "ottoman", "recliner", "settee", "cushion"],
    Bed: ["bed", "headboard", "mattress", "nightstand", "wardrobe"],
    "Office Table": ["office", "desk", "workstation", "conference"],
    Panel: ["panel", "door", "shutter", "carcass", "unit", "patta", "cabinet"]
  }
};
