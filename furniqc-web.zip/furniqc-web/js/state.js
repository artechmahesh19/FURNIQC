// ============================================================
// FurniQc — data model & local persistence
// Everything here mirrors the entities defined in the spec doc
// (§2 Core data model): Job Card, Dr No, QC Inspection,
// Parameter Result, Photo, QC Record.
//
// Local storage acts as the offline queue (§8 non-functional):
// inspectors on a weak-signal factory floor keep working, and
// a background sync pushes queued records to Drive/Sheets once
// the connection is back.
// ============================================================

const STORAGE_KEY = "furniqc_state_v1";

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error("Failed to load local state, starting fresh:", e);
  }
  return {
    artProjects: {},   // artNo -> { artNo, projectName, client, poNo, drItems: {} }
    inspections: {},   // inspectionId -> QC Inspection record (see makeInspection)
    syncQueue: []       // inspectionIds waiting to be pushed to Drive/Sheets
  };
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(APP_STATE));
}

let APP_STATE = loadState();

// ---- Art Project / Dr No helpers -------------------------------------

function upsertArtProject({ artNo, projectName, client, poNo }) {
  if (!APP_STATE.artProjects[artNo]) {
    APP_STATE.artProjects[artNo] = { artNo, projectName, client, poNo, drItems: {} };
  } else {
    Object.assign(APP_STATE.artProjects[artNo], { projectName, client, poNo });
  }
  saveState();
  return APP_STATE.artProjects[artNo];
}

function upsertDrItem(artNo, drItem) {
  const project = APP_STATE.artProjects[artNo];
  if (!project) throw new Error(`Unknown Art No ${artNo} — create the project first`);
  project.drItems[drItem.drNo] = { ...project.drItems[drItem.drNo], ...drItem };
  saveState();
  return project.drItems[drItem.drNo];
}

function deleteDrItem(artNo, drNo) {
  const project = APP_STATE.artProjects[artNo];
  if (project) {
    delete project.drItems[drNo];
    saveState();
  }
}

// ---- QC Inspection helpers --------------------------------------------

function detectDepartment(productName, drNo) {
  const text = `${productName} ${drNo}`.toLowerCase();
  for (const [dept, keywords] of Object.entries(CONFIG.DEPARTMENT_KEYWORDS)) {
    if (keywords.some((k) => text.includes(k))) return dept;
  }
  return "Panel"; // sensible default per the sample Job Card data (carcass/shutter items)
}

function makeInspection({ artNo, qcType, inspector }) {
  const id = `insp_${artNo}_${Date.now()}`;
  const inspection = {
    id,
    artNo,
    qcType,               // "Fresh QC" | "Re-QC"
    qcDate: new Date().toISOString().slice(0, 10),
    inspector: inspector || "Unassigned",
    linkedFreshQcId: null, // set when qcType === "Re-QC" (§10-A-3 reconciled linkage)
    lineItems: {},         // drNo -> { drNo, productName, size, qty, department,
                            //           parameters: { paramName: { state, reason, severity } },
                            //           remarks, photos: [{ id, driveFileId, localUrl }] }
    status: "draft",       // "draft" | "approved" | "rejected"
    createdAt: Date.now()
  };
  APP_STATE.inspections[id] = inspection;
  saveState();
  return inspection;
}

function addLineItemToInspection(inspectionId, drItem) {
  const insp = APP_STATE.inspections[inspectionId];
  const params = {};
  CONFIG.QC_PARAMETERS.forEach((p) => (params[p] = { state: "N/A", reason: null, severity: null }));
  insp.lineItems[drItem.drNo] = {
    drNo: drItem.drNo,
    productName: drItem.productName,
    size: drItem.size || "",
    qty: drItem.qty || 1,
    department: detectDepartment(drItem.productName, drItem.drNo),
    parameters: params,
    remarks: "",
    photos: []
  };
  saveState();
  return insp.lineItems[drItem.drNo];
}

// §4a — Partial QC: drop a Dr No from this inspection session entirely
// (not marked rejected, simply excluded — picked up in a later Fresh QC)
function excludeLineItem(inspectionId, drNo) {
  const insp = APP_STATE.inspections[inspectionId];
  delete insp.lineItems[drNo];
  saveState();
}

function setParameterResult(inspectionId, drNo, paramName, { state, reason, severity }) {
  const item = APP_STATE.inspections[inspectionId].lineItems[drNo];
  item.parameters[paramName] = { state, reason: reason || null, severity: severity || null };
  saveState();
}

function addPhotoToLineItem(inspectionId, drNo, photo) {
  APP_STATE.inspections[inspectionId].lineItems[drNo].photos.push(photo);
  saveState();
}

function deletePhotoFromLineItem(inspectionId, drNo, photoId) {
  const item = APP_STATE.inspections[inspectionId].lineItems[drNo];
  item.photos = item.photos.filter((p) => p.id !== photoId);
  saveState();
}

// Recapture replaces the photo in place (same array index) rather than
// deleting then re-adding, so it keeps its position/parameter tag.
function recapturePhoto(inspectionId, drNo, photoId, newPhoto) {
  const item = APP_STATE.inspections[inspectionId].lineItems[drNo];
  const idx = item.photos.findIndex((p) => p.id === photoId);
  if (idx > -1) item.photos[idx] = { ...item.photos[idx], ...newPhoto, id: photoId };
  saveState();
}

function computeInspectionStatus(inspection) {
  const items = Object.values(inspection.lineItems);
  const anyRejected = items.some((item) =>
    Object.values(item.parameters).some((p) => p.state === "Rejected")
  );
  return anyRejected ? "rejected" : "approved";
}

function finalizeInspection(inspectionId) {
  const insp = APP_STATE.inspections[inspectionId];
  insp.status = computeInspectionStatus(insp);
  insp.savedAt = Date.now();
  if (!APP_STATE.syncQueue.includes(inspectionId)) {
    APP_STATE.syncQueue.push(inspectionId);
  }
  saveState();
  return insp;
}

function deleteInspection(inspectionId) {
  delete APP_STATE.inspections[inspectionId];
  APP_STATE.syncQueue = APP_STATE.syncQueue.filter((id) => id !== inspectionId);
  saveState();
}

// ---- Dashboard aggregation (mirrors what also gets written to the
//      Google Sheets "Dashboard" tab — see js/googleSheets.js) ---------

function getDashboardStats() {
  const stats = {};
  CONFIG.DEPARTMENTS.forEach((d) => (stats[d] = { approved: 0, rejected: 0 }));

  Object.values(APP_STATE.inspections).forEach((insp) => {
    if (insp.status !== "approved" && insp.status !== "rejected") return;
    Object.values(insp.lineItems).forEach((item) => {
      const dept = stats[item.department] ? item.department : "Panel";
      const itemRejected = Object.values(item.parameters).some((p) => p.state === "Rejected");
      stats[dept][itemRejected ? "rejected" : "approved"] += 1;
    });
  });

  Object.keys(stats).forEach((dept) => {
    const { approved, rejected } = stats[dept];
    const total = approved + rejected;
    stats[dept].total = total;
    stats[dept].pctApproved = total ? Math.round((approved / total) * 100) : 0;
    stats[dept].pctRejected = total ? Math.round((rejected / total) * 100) : 0;
  });

  return stats;
}
