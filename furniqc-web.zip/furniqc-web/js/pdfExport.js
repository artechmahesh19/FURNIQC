// ============================================================
// FurniQc — QC PDF export (§7 of the spec)
// Uses jsPDF (loaded via CDN in index.html).
//
// PRIMARY export: one PDF per Art No containing every inspected
// Dr No as a repeating section — mirrors the layout of the
// original Job Card PDF (which stacks DR 405/406/407/408 in one
// document). This is the confirmed default/primary output.
//
// SECONDARY export: a single Dr No's section alone, for the
// "Download PDF" action on one record in the QC log.
// ============================================================

const PdfExport = (() => {
  function drawHeader(doc, project, inspection, y) {
    doc.setFontSize(14);
    doc.text("FurniQc — QC Report", 14, y);
    doc.setFontSize(10);
    doc.text(`Project: ${project.projectName}`, 14, y + 8);
    doc.text(`Art No: ${project.artNo}`, 14, y + 14);
    doc.text(`Client: ${project.client || "-"}   PO No: ${project.poNo || "-"}`, 14, y + 20);
    doc.text(`QC Date: ${inspection.qcDate}   QC Type: ${inspection.qcType}   Inspector: ${inspection.inspector}`, 14, y + 26);
    return y + 34;
  }

  function drawLineItemSection(doc, item, y) {
    if (y > 260) {
      doc.addPage();
      y = 14;
    }
    doc.setFontSize(11);
    doc.setFont(undefined, "bold");
    doc.text(`${item.drNo} — ${item.productName}`, 14, y);
    doc.setFont(undefined, "normal");
    doc.setFontSize(9);
    doc.text(`Size: ${item.size}   Qty: ${item.qty}   Department: ${item.department}`, 14, y + 6);

    let rowY = y + 12;
    Object.entries(item.parameters).forEach(([param, result]) => {
      const line = `${param}: ${result.state}` +
        (result.state === "Rejected"
          ? ` (Reason: ${result.reason || "-"}, Severity: ${result.severity || "-"})`
          : "");
      doc.text(line, 18, rowY);
      rowY += 5;
    });

    if (item.remarks) {
      doc.text(`Remarks: ${item.remarks}`, 18, rowY);
      rowY += 5;
    }

    const anyRejected = Object.values(item.parameters).some((p) => p.state === "Rejected");
    doc.setFont(undefined, "bold");
    doc.text(`Result: ${anyRejected ? "REJECTED" : "APPROVED"}`, 18, rowY + 2);
    doc.setFont(undefined, "normal");

    return rowY + 10;
  }

  // PRIMARY: combined Art-No-wise PDF, one section per Dr No, single file.
  function exportArtWisePdf(project, inspection) {
    const doc = new jspdf.jsPDF();
    let y = drawHeader(doc, project, inspection, 14);
    doc.line(14, y, 196, y);
    y += 8;

    Object.values(inspection.lineItems).forEach((item) => {
      y = drawLineItemSection(doc, item, y);
      doc.line(14, y - 4, 196, y - 4);
      y += 4;
    });

    const overallStatus = Object.values(inspection.lineItems).some((item) =>
      Object.values(item.parameters).some((p) => p.state === "Rejected")
    )
      ? "OVERALL: REJECTED — see items above"
      : "OVERALL: APPROVED";
    doc.setFontSize(12);
    doc.setFont(undefined, "bold");
    doc.text(overallStatus, 14, y + 6);

    doc.save(`${project.artNo}_${inspection.qcType.replace(/\s+/g, "")}_${inspection.qcDate}.pdf`);
  }

  // SECONDARY: single Dr No record only.
  function exportSingleDrNoPdf(project, inspection, drNo) {
    const doc = new jspdf.jsPDF();
    let y = drawHeader(doc, project, inspection, 14);
    doc.line(14, y, 196, y);
    y += 8;
    drawLineItemSection(doc, inspection.lineItems[drNo], y);
    doc.save(`${project.artNo}_${drNo}_${inspection.qcDate}.pdf`);
  }

  return { exportArtWisePdf, exportSingleDrNoPdf };
})();
