// ============================================================
// FurniQc — Google Drive photo backup, organized Art No wise
//
// Folder structure (confirmed in spec §5):
//   FurniQc / {Art No} / {Dr No} / {QC Date}_{QC Type} / photo_001.jpg
//
// Photos upload immediately on capture (confirmed §9 Open Q4),
// each with its own ✕ delete and ↻ recapture (which re-uploads
// into the *same* Drive file, overwriting it, so the folder
// never accumulates orphaned retakes).
// ============================================================

const GoogleDrive = (() => {
  const folderCache = {}; // "parentId::name" -> folderId, avoids repeat lookups

  async function findOrCreateFolder(name, parentId) {
    const cacheKey = `${parentId || "root"}::${name}`;
    if (folderCache[cacheKey]) return folderCache[cacheKey];

    const q = [
      `name='${name.replace(/'/g, "\\'")}'`,
      "mimeType='application/vnd.google-apps.folder'",
      "trashed=false",
      parentId ? `'${parentId}' in parents` : "'root' in parents"
    ].join(" and ");

    const searchResp = await gapi.client.drive.files.list({
      q,
      fields: "files(id, name)",
      spaces: "drive"
    });

    if (searchResp.result.files && searchResp.result.files.length > 0) {
      folderCache[cacheKey] = searchResp.result.files[0].id;
      return folderCache[cacheKey];
    }

    const createResp = await gapi.client.drive.files.create({
      resource: {
        name,
        mimeType: "application/vnd.google-apps.folder",
        parents: parentId ? [parentId] : undefined
      },
      fields: "id"
    });
    folderCache[cacheKey] = createResp.result.id;
    return folderCache[cacheKey];
  }

  // Walks/creates FurniQc / {artNo} / {drNo} / {qcDate}_{qcType} and returns
  // that innermost folder's ID, ready to receive photo_00X.jpg files.
  async function ensureArtWiseFolderPath({ artNo, drNo, qcDate, qcType }) {
    const rootId = await findOrCreateFolder(CONFIG.DRIVE_ROOT_FOLDER_NAME, null);
    const artId = await findOrCreateFolder(artNo, rootId);
    const drId = await findOrCreateFolder(drNo, artId);
    const sessionId = await findOrCreateFolder(`${qcDate}_${qcType.replace(/\s+/g, "")}`, drId);
    return sessionId;
  }

  // Compresses an image blob client-side before upload (confirmed §10-B-6)
  // to keep factory-floor uploads fast on weak signal.
  function compressImage(blob, maxDim = 1600, quality = 0.75) {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
        const canvas = document.createElement("canvas");
        canvas.width = img.width * scale;
        canvas.height = img.height * scale;
        canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
        canvas.toBlob((compressed) => resolve(compressed || blob), "image/jpeg", quality);
      };
      img.src = URL.createObjectURL(blob);
    });
  }

  async function uploadPhoto({ artNo, drNo, qcDate, qcType, fileBlob, fileName }) {
    const folderId = await ensureArtWiseFolderPath({ artNo, drNo, qcDate, qcType });
    const compressed = await compressImage(fileBlob);

    const metadata = { name: fileName, parents: [folderId] };
    const form = new FormData();
    form.append("metadata", new Blob([JSON.stringify(metadata)], { type: "application/json" }));
    form.append("file", compressed);

    const resp = await fetch(
      "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,webViewLink",
      {
        method: "POST",
        headers: { Authorization: `Bearer ${gapi.client.getToken().access_token}` },
        body: form
      }
    );
    return resp.json(); // { id, webViewLink }
  }

  // Recapture: overwrite the existing Drive file in place (PATCH media)
  // instead of creating a new one, so the folder count stays accurate.
  async function overwritePhoto({ driveFileId, fileBlob }) {
    const compressed = await compressImage(fileBlob);
    const resp = await fetch(
      `https://www.googleapis.com/upload/drive/v3/files/${driveFileId}?uploadType=media`,
      {
        method: "PATCH",
        headers: {
          Authorization: `Bearer ${gapi.client.getToken().access_token}`,
          "Content-Type": "image/jpeg"
        },
        body: compressed
      }
    );
    return resp.json();
  }

  async function deletePhoto(driveFileId) {
    return gapi.client.drive.files.delete({ fileId: driveFileId });
  }

  return { uploadPhoto, overwritePhoto, deletePhoto, ensureArtWiseFolderPath };
})();
