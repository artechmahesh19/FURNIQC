// ============================================================
// FurniQc — Job Card PDF import
// Uses pdf.js (loaded via CDN in index.html) to pull text out of
// an Artech-style Job Card PDF, then regex-parses the header
// fields and the repeating "DR NO ###" line-item blocks.
//
// This mirrors exactly what §4 Step 2/3 of the spec describes:
// Art No = "Order Number", Project Name = "Order Name",
// each "DR NO xxx" block = one Dr No line item with
// Product Name / Size (W×D×H) / Qty.
// ============================================================

const PdfImport = (() => {
  async function extractText(fileArrayBuffer) {
    const pdf = await pdfjsLib.getDocument({ data: fileArrayBuffer }).promise;
    let fullText = "";
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const content = await page.getTextContent();
      fullText += content.items.map((it) => it.str).join(" ") + "\n";
    }
    return fullText;
  }

  function parseHeader(text) {
    const artNo = (text.match(/Order Number\s*([A-Z]+\s*-?\s*\d+)/i) || [])[1];
    const projectName = (text.match(/Order Name\s+(.+?)\s+(?:PO Number|Dispatch Date)/i) || [])[1];
    const poNo = (text.match(/PO Number & Date\s*([^\n]*)/i) || [])[1];
    return {
      artNo: artNo ? artNo.replace(/\s+/g, "") : "",
      projectName: (projectName || "").trim(),
      poNo: (poNo || "").trim()
    };
  }

  // Each Job Card line item repeats as:
  //   DR NO 405   TALL UNIT -BASE CARCASS   1015  440  1095   1
  // (Drawing No, Product Name, W, D, H, Qty) — matches sample.pdf's layout.
  function parseLineItems(text) {
    const items = [];
    const re = /DR\s*NO\s*(\d+)\s+([A-Z0-9 \-()\/]+?)\s+(\d{2,4})\s+(\d{2,4})\s+(\d{2,4})\s+(\d{1,3})\b/gi;
    let match;
    while ((match = re.exec(text)) !== null) {
      const [, drNo, productNameRaw, w, d, h, qty] = match;
      items.push({
        drNo: `DR-${drNo}`,
        productName: productNameRaw.trim().replace(/\s+/g, " "),
        size: `${w} x ${d} x ${h}`,
        qty: parseInt(qty, 10)
      });
    }
    return items;
  }

  async function parseJobCardPdf(file) {
    const buffer = await file.arrayBuffer();
    const text = await extractText(buffer);
    const header = parseHeader(text);
    const lineItems = parseLineItems(text);
    return { ...header, lineItems };
  }

  return { parseJobCardPdf };
})();
