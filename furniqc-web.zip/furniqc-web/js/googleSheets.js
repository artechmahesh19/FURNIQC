// ============================================================
// FurniQc — Google Sheets auto-report
//
// Appends one row per Dr No to CONFIG.QC_LOG_SHEET_NAME, in the
// exact column order used by your existing QC_REPORT_.xlsx:
//   Sr No | Date | Client | Project Name | Po No | Department |
//   Job Card No | Dr No | Product Name | Qty | Size |
//   Outer/Polish/Veneer/Pu/Metal | Edgeband | GVT/Leg | Glass/Lock |
//   Design As Per Drawing | Handle/Knob/Profile | Fabric | Metal |
//   Remark | QC Approved or Reject
//
// (Job Card No column is kept for compatibility with the existing
// sheet, but is always written equal to Art No — confirmed §9 Q3:
// no separate Job Card No is tracked in the app.)
//
// Also maintains CONFIG.DASHBOARD_SHEET_NAME: department-wise
// Approved/Rejected counts and % Approved/% Rejected.
// ============================================================

const GoogleSheets = (() => {
  const PARAM_TO_COLUMN = CONFIG.QC_PARAMETERS; // same order as the xlsx

  function paramSymbol(state) {
    if (state === "OK") return "\u2713";        // ✓
    if (state === "Rejected") return "\u2718";   // ✘
    return "\u2610";                              // ☐  (N/A)
  }

  // Builds one sheet row (array of cell values) for a single Dr No line item.
  function buildRow({ srNo, inspection, project, lineItem }) {
    const overallRejected = Object.values(lineItem.parameters).some((p) => p.state === "Rejected");
    const paramCells = PARAM_TO_COLUMN.map((p) => paramSymbol(lineItem.parameters[p].state));

    // Fold any per-parameter rejection reason/severity into the Remark cell,
    // since the xlsx only has one free-text Remark column.
    const rejectionNotes = Object.entries(lineItem.parameters)
      .filter(([, v]) => v.state === "Rejected")
      .map(([name, v]) => `${name}: ${v.reason || "Other"}${v.severity ? " (" + v.severity + ")" : ""}`)
      .join("; ");
    const remark = [lineItem.remarks, rejectionNotes].filter(Boolean).join(" — ");

    return [
      srNo,
      inspection.qcDate,
      project.client || "",
      project.projectName,
      project.poNo || "",
      lineItem.department,
      project.artNo,          // Job Card No column = Art No (confirmed §9 Q3)
      lineItem.drNo,
      lineItem.productName,
      lineItem.qty,
      lineItem.size,
      ...paramCells,
      remark,
      overallRejected ? "QC REJECTED" : "QC APPROVED"
    ];
  }

  async function getNextSrNo() {
    const resp = await gapi.client.sheets.spreadsheets.values.get({
      spreadsheetId: CONFIG.QC_REPORT_SPREADSHEET_ID,
      range: `${CONFIG.QC_LOG_SHEET_NAME}!A:A`
    });
    const rows = resp.result.values || [];
    return rows.length; // header is row 1, so row count = next Sr No
  }

  // Appends every Dr No in the inspection as its own row (confirmed:
  // Fresh QC and Re-QC each write their own separate rows — §9 Q5 —
  // with linkedFreshQcId only used for in-app traceability, not a sheet column).
  async function appendInspection(inspection, project) {
    let srNo = await getNextSrNo();
    const rows = Object.values(inspection.lineItems).map((item) => {
      srNo += 1;
      return buildRow({ srNo, inspection, project, lineItem: item });
    });

    if (rows.length === 0) return;

    await gapi.client.sheets.spreadsheets.values.append({
      spreadsheetId: CONFIG.QC_REPORT_SPREADSHEET_ID,
      range: `${CONFIG.QC_LOG_SHEET_NAME}!A:U`,
      valueInputOption: "RAW",
      insertDataOption: "INSERT_ROWS",
      resource: { values: rows }
    });

    await updateDashboard();
  }

  // Recomputes the Dashboard tab from the full QC log and overwrites it.
  // Kept simple/dumb (read everything, recompute, rewrite) since QC volume
  // is small enough that this is cheap and avoids drift from partial updates.
  async function updateDashboard() {
    const logResp = await gapi.client.sheets.spreadsheets.values.get({
      spreadsheetId: CONFIG.QC_REPORT_SPREADSHEET_ID,
      range: `${CONFIG.QC_LOG_SHEET_NAME}!A2:U`
    });
    const rows = logResp.result.values || [];
    const deptColIdx = 5;   // "Department" — column F (0-indexed 5)
    const resultColIdx = 20; // "QC Approved or Reject" — column U (0-indexed 20)

    const stats = {};
    CONFIG.DEPARTMENTS.forEach((d) => (stats[d] = { approved: 0, rejected: 0 }));

    rows.forEach((row) => {
      const dept = stats[row[deptColIdx]] ? row[deptColIdx] : "Panel";
      const approved = (row[resultColIdx] || "").includes("APPROVED");
      stats[dept][approved ? "approved" : "rejected"] += 1;
    });

    const dashRows = [
      ["Department", "Approved", "Rejected", "Total", "% Approved", "% Rejected"]
    ];
    Object.entries(stats).forEach(([dept, s]) => {
      const total = s.approved + s.rejected;
      dashRows.push([
        dept,
        s.approved,
        s.rejected,
        total,
        total ? `${Math.round((s.approved / total) * 100)}%` : "0%",
        total ? `${Math.round((s.rejected / total) * 100)}%` : "0%"
      ]);
    });

    await gapi.client.sheets.spreadsheets.values.update({
      spreadsheetId: CONFIG.QC_REPORT_SPREADSHEET_ID,
      range: `${CONFIG.DASHBOARD_SHEET_NAME}!A1:F${dashRows.length}`,
      valueInputOption: "RAW",
      resource: { values: dashRows }
    });
  }

  return { appendInspection, updateDashboard };
})();
